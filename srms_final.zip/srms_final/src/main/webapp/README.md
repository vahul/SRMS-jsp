# Student-Results-Management-System

![Home-Page](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/d9f4556c-d1c4-41ce-9e8b-9a558f53e3f6)

![Home-page-2](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/403bcdd0-0be6-45c3-8de4-df399e53fc0a)

![AdminLogin](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/61ab2f6d-0047-4e0c-a543-97ce84700e7c)

![Insert-New-Student](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/11009f27-ba1e-4748-89c5-881c13951016)

![Insert-Results](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/6a0b8ea3-7b6b-4edc-b02a-251bda60a12e)

![Student-Details](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/3eb2cbf3-8022-47e2-b6f5-550216c0095a)

![Update-Results](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/5f2adaf9-2816-4601-ae68-5ba2d22418ee)

![Update-Details](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/b12a4bf9-5c03-4be1-ab62-e937ad804b16)

![Search-Bar](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/fdb7e948-a5fd-4841-9958-73271fa65018)![Search-bar-Result](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/c35f2e9a-cb13-40cd-a49d-e25577a7e79e)

![Student-Login](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/dab37231-a0b2-4ac4-a4c3-9ad9b34b845b)

![Student-Result](https://github.com/MenatiVasudevaReddy/Student-Results-Management-System/assets/101622707/cd804f81-7b18-4781-ac0f-72e98f7f7800)

